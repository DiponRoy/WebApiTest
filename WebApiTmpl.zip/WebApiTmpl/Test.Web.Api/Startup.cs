﻿using Test.Web.Api.Startups;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Test.Web.Api
{
    public class Startup
    {
        public IConfiguration Configuration { get; }

        public Startup(IConfiguration configuration, IHostingEnvironment env)
        {
            Configuration = configuration;
            ErrorSetup.Startup(configuration);
        }


        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            ApiSetup.Configure(services);
            TokenAuthStartup.Configure(services, Configuration);
            MapperStartup.Configure(services);
            MvcStartup.Configure(services);
            DependencyInjectionStartup.Configure(services, Configuration);
            ValidationStartup.ConfigureServices(services);
            ApiDocStartup.ConfigureServices(services);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            ErrorSetup.Configure(app);
            ApiSetup.Configure(app);
            TokenAuthStartup.InitializeAuthentication(app, env);
            MvcStartup.Configure(app, env);
            ApiDocStartup.Configure(app);
        }
    }
}
