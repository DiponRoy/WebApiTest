﻿

using Cfs.Admin.Web.Api.Data.Repo;
using Cfs.Admin.Web.Api.Models;
using Db.Cfs;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cfs.Admin.Web.Api.Validators
{
    /// <summary>
    /// Channel create validations
    /// </summary>
    public class ChannelCreateValidator : AbstractValidator<ChannelCreateModel>
    {
        public ChannelCreateValidator(ICfsDbContext db)
        {
            RuleFor(x => x.Id)
                .NotEmpty()
                .Must(p => new UserChannelRepo(db).Find(p) == null)
                .WithMessage("Channel already exists with this name.");
        }
    }

    /// <summary>
    /// Channel delete validations
    /// </summary>
    public class ChannelDeleteValidator : AbstractValidator<ChannelDeleteModel>
    {
        public ChannelDeleteValidator(ICfsDbContext db)
        {
            RuleFor(x => x.Id)
                .NotEmpty()
                .Must(p => new UserChannelRepo(db).Find(p) != null)
                .WithMessage("Channel not found.")
                .Must(p => new UserChannelPartnerRepo(db).GetByChannel(p).Count() == 0)
                .WithMessage("Need to remove partner from this channel.")
                .Must(p => new UserRepo(db).GetByChannel(p).Count() == 0)
                .WithMessage("Need to remove users from this channel.");
        }
    }
}
