﻿using System;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.IdentityModel.Tokens;
using Microsoft.Extensions.Configuration;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using System.Security.Claims;
using System.IdentityModel.Tokens.Jwt;
using Test.Web.Api.Models;
using System.Collections.Generic;
using System.Linq;

namespace Test.Web.Api.Startups
{
    /*
     * Token: https://www.c-sharpcorner.com/article/jwt-json-web-token-authentication-in-asp-net-core/
     * Access claims: https://www.koskila.net/how-to-get-current-user-in-asp-net-core/
     */
    internal class TokenAuthStartup
    {
        internal static void Configure(IServiceCollection services, IConfiguration configuration)
        {
            string issuer = configuration["Jwt:Issuer"];
            string key = configuration["Jwt:Key"];


            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                {
                    options.TokenValidationParameters = new TokenValidationParameters
                    {
                        ValidateLifetime = true,
                        ValidateIssuerSigningKey = true,
                        ValidateIssuer = true,
                        ValidIssuer = issuer,
                        ValidateAudience = false,
                        //ValidAudience = issuer,
                        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key))
                    };
                });
        }

        internal static void InitializeAuthentication(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseAuthentication();
        }

    }
}