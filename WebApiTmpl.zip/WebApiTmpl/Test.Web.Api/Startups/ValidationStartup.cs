﻿
using Test.Web.Api.Models;
using Test.Web.Api.Validators;
using FluentValidation;
using FluentValidation.AspNetCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Web.Api.Startups
{
    internal class ValidationStartup
    {
        public static void ConfigureServices(IServiceCollection services)
        {
            //ValidatorOptions.CascadeMode = CascadeMode.StopOnFirstFailure;

            /*Model wise validators mapp*/
            //services.AddSingleton<IValidator<DelegateMappCreateModel>, DelegateMappCreateValidator>();
            //services.AddSingleton<IValidator<RoleMappCreateModel>, RoleMappCreateValidator>();

            services.AddMvc(opt =>
            {
                opt.Filters.Add(typeof(ValidatorActionFilter));                                     /*validate on post*/
            })
            .AddFluentValidation(fvc => fvc.RegisterValidatorsFromAssemblyContaining<Startup>());   /*load all validators from assembly*/
        }
    }
}
