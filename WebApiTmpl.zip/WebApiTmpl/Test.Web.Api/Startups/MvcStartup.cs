﻿/*
 * Links
 * Ignore Authentication: https://www.illucit.com/asp-net/asp-net-core-2-0-disable-authentication-development-environment/
 * Authorize attribute https://stackoverflow.com/questions/34994846/how-to-protect-all-controllers-by-default-with-bearer-token-in-asp-net-core-asp
*/

using System;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Authorization;
using Microsoft.Extensions.DependencyInjection;

namespace Test.Web.Api.Startups
{
    internal class MvcStartup
    {
        private static IServiceCollection _services;

        internal static void Configure(IServiceCollection services)
        {
            _services = services;
            ApplyAuthentication(services).SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            //services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
        }



        private static IMvcBuilder ApplyAuthentication(IServiceCollection services)
        {
            IMvcBuilder builder;

            /*all controller with Authorize attribute*/
            builder = services.AddMvc(opts =>
            {
                var policy = new AuthorizationPolicyBuilder()
                    .RequireAuthenticatedUser()
                    .Build();
                opts.Filters.Add(new AuthorizeFilter(policy));
            });

            /*all controller with AllowAnonymous attribute*/
            //builder = services.AddMvc(opts =>
            //{
            //    opts.Filters.Add(new AllowAnonymousFilter());
            //});

            return builder;
        }


        internal static void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseMvc();
        }
    }
}