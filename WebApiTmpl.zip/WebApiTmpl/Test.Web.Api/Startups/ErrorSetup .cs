﻿

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.Extensions.Configuration;
using Serilog;
using Serilog.Events;
using System.IO;

namespace Test.Web.Api.Startups
{
    internal class ErrorSetup
    {
        internal static void Startup(IConfiguration configuration)
        {
            /*
             * https://stackoverflow.com/questions/40880261/configuring-serilog-rollingfile-with-appsettings-json
             * https://medium.com/@matthew.bajorek/configuring-serilog-in-asp-net-core-2-2-web-api-5e0f4d89749c
             * https://jkdev.me/asp-net-core-serilog/
             */
            string directory = configuration["serilog:webApiErrorDir"];
            string fileName = @"{Date}.txt";     /*yyyyMMdd*/
            string path = Path.Combine(directory, fileName);
            Log.Logger = new LoggerConfiguration()
               .MinimumLevel
               .Information()
               .WriteTo.RollingFile(path, LogEventLevel.Information)
               .CreateLogger();
        }

        internal static void Configure(IApplicationBuilder app)
        {
            /*https://stackoverflow.com/questions/38630076/asp-net-core-web-api-exception-handling*/
            app.UseExceptionHandler(a => a.Run(async context =>
            {
                var feature = context.Features.Get<IExceptionHandlerPathFeature>();
                var exception = feature.Error;
                Log.Error(exception, exception.Message);

            }));
        }
    }
}
