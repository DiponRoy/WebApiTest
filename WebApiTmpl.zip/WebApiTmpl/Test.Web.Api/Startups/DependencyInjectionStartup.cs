﻿
using Test.Web.Api.Db;
using Test.Web.Api.Security;
using Db.Test;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Test.Web.Api.Startups
{
    internal class DependencyInjectionStartup
    {
        internal static void Configure(IServiceCollection services, IConfiguration configuration)
        {
            /*Db*/
            services.AddScoped<IAppDbContext, AppDb>();
            ////services.AddDbContext<AppDb>(options => options.UseSqlServer(configuration.GetConnectionString("AppDbConnection")));

            /*others*/
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddScoped<ILdapValidate, LdapManager>();
        }
    }
}