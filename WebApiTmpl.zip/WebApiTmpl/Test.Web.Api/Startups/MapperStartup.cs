﻿/*
 * Links:
 * https://stackoverflow.com/questions/40275195/how-to-set-up-automapper-in-asp-net-core
 * https://www.infoworld.com/article/3192900/how-to-work-with-automapper-in-c.html
*/
using AutoMapper;
using Microsoft.Extensions.DependencyInjection;

namespace Test.Web.Api.Startups
{
    internal class MapperStartup
    {
        internal static void Configure(IServiceCollection services)
        {
            var mappingConfig = new MapperConfiguration(mc =>
            {
                mc.AddProfile(new TableMappingProfile());
                mc.AddProfile(new ApiModelMappingProfile());
            });
            IMapper mapper = mappingConfig.CreateMapper();
            services.AddSingleton(mapper);
        }
    }

    public class TableMappingProfile : Profile
    {
        public TableMappingProfile()
        {
        }
    }

    public class ApiModelMappingProfile : Profile
    {
        public ApiModelMappingProfile()
        {
        }
    }
}