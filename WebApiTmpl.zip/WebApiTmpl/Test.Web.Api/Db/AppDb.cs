﻿using Db.Test;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;

namespace Test.Web.Api.Db
{

    public class AppDb : DbContext, IAppDbContext
    {
        public AppDb() 
        {
        }
    }
}
