﻿namespace Db.Test
{
    public interface IAppDbContext
    {
    }
}
