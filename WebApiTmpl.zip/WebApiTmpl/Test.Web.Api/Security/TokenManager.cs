﻿/*
 * Links
 * Token: https://www.c-sharpcorner.com/article/jwt-json-web-token-authentication-in-asp-net-core/
 * Access claims: https://www.koskila.net/how-to-get-current-user-in-asp-net-core/
*/

using Test.Web.Api.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;

namespace Test.Web.Api.Security
{

    /// <summary>
    /// Token related tasks manager
    /// </summary>
    public class TokenManager
    {
        /*claim indexs*/
        protected const string ClaimJti = JwtRegisteredClaimNames.Jti;
        /*web config values*/
        public readonly int TokenDurationInHours;
        public readonly string TokenIssuer;
        public readonly string TokenKey;

        public TokenManager(IConfiguration config)
        {
            TokenDurationInHours = Convert.ToInt32(config["Jwt:ExpireDurationInHours"]);
            TokenIssuer = config["Jwt:Issuer"];
            TokenKey = config["Jwt:Key"];
        }

        /// <summary>
        /// Create token from user details
        /// </summary>
        /// <param name="user">User details</param>
        /// <returns></returns>
        internal string Token(LoginUserDetail user)
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(TokenKey));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var claims = new ClaimManager().Claims(user).ToList();
            claims.Add(new Claim(ClaimJti, Guid.NewGuid().ToString()));
            var token = new JwtSecurityToken(
                issuer: TokenIssuer,
                //audience: TokenIssuer,
                claims: claims,
                expires: DateTime.Now.AddHours(TokenDurationInHours),
                signingCredentials: credentials);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
