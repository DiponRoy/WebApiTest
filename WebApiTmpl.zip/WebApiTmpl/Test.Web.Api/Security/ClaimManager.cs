﻿/*
 * Links
 * Token: https://www.c-sharpcorner.com/article/jwt-json-web-token-authentication-in-asp-net-core/
 * Access claims: https://www.koskila.net/how-to-get-current-user-in-asp-net-core/
*/

using Test.Web.Api.Models;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace Test.Web.Api.Security
{
    /// <summary>
    /// Claim related tasks manager
    /// </summary>
    public class ClaimManager
    {
        /*claim indexs*/
        protected const string ClaimUserId = "UserId";
        protected const string ClaimEmail = "Email";

        /// <summary>
        /// Convert user details to claim list
        /// </summary>
        /// <param name="user">User details</param>
        /// <returns></returns>
        public IEnumerable<Claim> Claims(LoginUserDetail user)
        {
            var claims = new[] {
                new Claim(ClaimUserId, user.UserName),
                new Claim(ClaimEmail, user.Email),
            };
            return claims;
        }

        /// <summary>
        /// Get current user from claims
        /// </summary>
        /// <param name="claims">Current user claims from HttpRequest.User</param>
        /// <returns></returns>
        internal CurrentUserModel SessionUser(IEnumerable<Claim> claims)
        {
            var entity = new CurrentUserModel();
            entity.Id = GetValue(claims, ClaimUserId);
            entity.Email = GetValue(claims, ClaimEmail);
            return entity;
        }

        private static string GetValue(IEnumerable<Claim> claims, string key)
        {
            var claim = claims.FirstOrDefault(x => x.Type.Equals(key));
            return claim.Value;
        }
    }

}
