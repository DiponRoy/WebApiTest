﻿/*
 * Links:
 * https://www.nuget.org/packages/Novell.Directory.Ldap.NETStandard/2.3.8
 * https://stackoverflow.com/a/49685121
 * https://stackoverflow.com/questions/37330705/working-with-directoryservices-in-asp-net-cores
*/


using Microsoft.Extensions.Configuration;
using Novell.Directory.Ldap;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Web.Api.Security
{
    /// <summary>
    /// Gp Ldap related contracts
    /// </summary>
    public interface ILdapValidate
    {
        /// <summary>
        /// Check if user in GP 
        /// </summary>
        /// <param name="userId">Gp user name without domain name</param>
        /// <param name="password">Gp passsword</param>
        bool Validate(string userId, string password);
    }

    /// <summary>
    /// Gp Ldap related tasks manager
    /// </summary>
    public class LdapManager : ILdapValidate
    {
        /// <summary>
        /// Domain name from config file
        /// </summary>
        public readonly string DomainName;
        /// <summary>
        /// Port name form config file, default 389
        /// </summary>
        public readonly int PortNumber;

        public LdapManager(IConfiguration config)
        {

            DomainName = config.GetValue<string>("Ldap:DomainName");
            try
            {
                PortNumber = config.GetValue<int>("Ldap:PortNumber");
            }
            catch (Exception)
            {
                PortNumber = LdapConnection.DEFAULT_PORT;
            }
        }

        /// <summary>
        /// Check if user in GP 
        /// </summary>
        /// <param name="userId">Gp user name without domain name</param>
        /// <param name="password">Gp passsword</param>
        public bool Validate(string userId, string password)
        {
            try
            {
                string username = UserFullId(userId);  
                using (var connection = new LdapConnection { SecureSocketLayer = false })
                {
                    connection.Connect(DomainName, PortNumber);
                    connection.Bind(username, password);
                    return connection.Bound;
                }
            }
            catch (LdapException ex)
            {
                return false;
            }
        }

        /// <summary>
        /// User full id 
        /// </summary>
        /// <param name="userId">User name</param>
        /// <returns>userName@domain</returns>
        public string UserFullId(string userId)
        {
            string value = string.Format(@"{0}@{1}", userId, DomainName);
            return value;
        }
    }
}
