﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Test.Web.Api.Controllers
{
    /// <summary>
    /// Test api get list, get single, post, put and delete
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    [AllowAnonymous]
    public class HelloController : ControllerBase
    {
        // GET api/hello
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET api/hello/5
        [HttpGet("{id}")]
        public ActionResult<string> Get(int id)
        {
            return id.ToString();
        }

        // POST api/hello
        [HttpPost]
        public string Post([FromBody] string value)
        {
            return value;
        }

        // PUT api/hello/5
        [HttpPut("{id}")]
        public string Put(int id, [FromBody] string value)
        {
            return String.Format("Id: {0}, Value: {1}", id, value);
        }

        // DELETE api/hello/5
        [HttpDelete("{id}")]
        public string Delete(int id)
        {
            return id.ToString();
        }

        // GET api/hello/authorizeGet
        [HttpGet]
        [Route("[action]")]
        [Authorize]
        public ActionResult<IEnumerable<string>> AuthorizeGet()
        {
            return new string[] { "value1", "value2" };
        }

    }
}
