﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Test.Web.Api.Db;
using Test.Web.Api.Models;
using Test.Web.Api.Security;
using Db.Test;
using Microsoft.AspNetCore.Mvc;

namespace Test.Web.Api.Controllers.Core
{
    /// <summary>
    /// Base api controller
    /// </summary>
    public abstract class AppApiController : ControllerBase
    {
        /// <summary>
        /// Current session user
        /// </summary>
        protected CurrentUserModel CurrentUser()
        {
            var entity = new ClaimManager().SessionUser(User.Claims);
            return entity;
        }

        /// <summary>
        /// Current session user's id
        /// </summary>
        protected string CurrentUserId()
        {
            //return "MoqUserId";
            var entity = new ClaimManager().SessionUser(User.Claims);
            return entity.Id;
        }
    }
}
