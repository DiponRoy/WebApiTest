﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cfs.Admin.Web.Api.Controllers.Core;
using Cfs.Admin.Web.Api.Data.Repo;
using Cfs.Admin.Web.Api.Db;
using Cfs.Admin.Web.Api.Models;
using Db.Cfs;
using Db.Cfs.Table;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Cfs.Admin.Web.Api.Controllers
{
    /// <summary>
    /// Manage user channel
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserChannelController : AppApiController
    {

        protected readonly ICfsDbContext Db;

        public UserChannelController(CfsDb db)
        {
            Db = db;
        }

        // GET: api/userChannel
        /// <summary>
        /// All user channel list
        /// </summary>
        [HttpGet]
        public IEnumerable<UserChannel> Get()
        {
            List<UserChannel> list = Db.UserChannel.ToList();
            return list;
        }

        // POST: api/userChannel
        /// <summary>
        /// Create user channel
        /// </summary>
        /// <param name="model">create model</param>
        [HttpPost]
        public UserChannel Post(ChannelCreateModel model)
        {
            UserChannel entity = new UserChannel
            {
                Id = model.Id,
                Details = model.Details
            };
            new UserChannelRepo(Db).Add(entity);
            Db.SaveChanges(CurrentUserId());
            return entity;
        }

        // DELETE: api/UserChannel/5
        /// <summary>
        /// Remove user channel
        /// </summary>
        /// <param name="id">Row id</param>
        //[HttpDelete("{id}")]
        //public void Delete(string id)
        [HttpPost]
        [Route("[action]")]
        public void Delete(ChannelDeleteModel model)
        {
            var repo = new UserChannelRepo(Db);
            var entity = repo.Find(model.Id);
            if (entity == null)
            {
                return;
            }
            repo.Remove(entity);
            Db.SaveChanges(CurrentUserId());
        }
    }
}
