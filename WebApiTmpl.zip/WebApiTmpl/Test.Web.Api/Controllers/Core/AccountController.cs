﻿using Test.Web.Api.Controllers.Core;
using Test.Web.Api.Db;
using Test.Web.Api.Models;
using Test.Web.Api.Security;
using Db.Test;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;

namespace Test.Web.Api.Controllers
{
    /// <summary>
    /// User session manage
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : AppApiController
    {
        public readonly IAppDbContext Db;
        public readonly IConfiguration Config;


        public AccountController(AppDb db, IConfiguration config)
        {
            Db = db;
            Config = config;
        }

        // GET api/account/Token
        /// <summary>
        /// Get token after validating user
        /// </summary>
        /// <returns>User token</returns>
        [HttpPost]
        [Route("[action]")]
        [AllowAnonymous]
        public ActionResult<TokenResponseModel> Token(TokenRequestModel model)
        {
            var user = new LoginUserDetail();
            var tokenDetails = new TokenResponseModel()
            {
                Token = new TokenManager(Config).Token(user)
            };
            return tokenDetails;
        }

        // GET api/account/userDetails
        /// <summary>
        /// User details of current user 
        /// </summary>
        /// <returns>User details</returns>
        [HttpGet]
        [Route("[action]")]
        public ActionResult<LoginUserDetail> UserDetails()
        {
            var currentUser = CurrentUser();
            var entity = new LoginUserDetail()
            {
                UserName = currentUser.Id,
                Email = currentUser.Email
            };
            return entity;
        }
    }
}
