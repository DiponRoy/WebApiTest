﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Test.Web.Api.Models
{
    /// <summary>
    /// Make request form token
    /// </summary>
    public class TokenRequestModel
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }

    /// <summary>
    /// Make response form token
    /// </summary>
    public class TokenResponseModel
    {
        public string Token { get; set; }
    }

    /// <summary>
    /// Session user details
    /// </summary>
    public class LoginUserDetail
    {
        public string UserName { get; set; }
        public string Email { get; set; }
    }

}
