﻿using System;

namespace Mutator.Db.Dwfs
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
