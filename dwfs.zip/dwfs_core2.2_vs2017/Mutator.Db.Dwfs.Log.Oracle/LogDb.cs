﻿using Db.Dwfs.Oracle;
using Dwfs.Core.Setting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Mutator.Db.Dwfs.Log.Oracle
{
    public class LogDb : DwfsLogOracleDbContext
    {
        public LogDb() : base()
        {

        }

        protected override string ConnectionString()
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"), optional: true);
            IConfigurationRoot configuration = builder.Build();

            var value = configuration.GetConnectionString("logDbConnection");
            return value;
        }
    }
}
