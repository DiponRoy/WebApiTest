﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace Mutator.Db.Dwfs.Log.Oracle.Migrations
{
    public partial class Init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.EnsureSchema(
                name: "ROSATEST");

            migrationBuilder.CreateTable(
                name: "Dwfs_FileLog",
                schema: "ROSATEST",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 40, nullable: false),
                    CreatedBy = table.Column<string>(maxLength: 100, nullable: true),
                    CreatedDateTime = table.Column<DateTime>(nullable: true),
                    UpdatedBy = table.Column<string>(maxLength: 100, nullable: true),
                    UpdatedDateTime = table.Column<DateTime>(nullable: true),
                    DataProcessStatus = table.Column<int>(nullable: false),
                    FileDataDate = table.Column<DateTime>(nullable: false),
                    FileName = table.Column<string>(maxLength: 150, nullable: true),
                    FileDataColumnCount = table.Column<int>(nullable: false),
                    FileDataRowCount = table.Column<int>(nullable: false),
                    ExportBatchId = table.Column<string>(maxLength: 40, nullable: true),
                    ExportedDateTime = table.Column<DateTime>(nullable: true),
                    ExportSqlQuery = table.Column<string>(nullable: true),
                    ExportAtMachine = table.Column<string>(maxLength: 250, nullable: true),
                    ExportAtAbsoluteDirectroy = table.Column<string>(maxLength: 250, nullable: true),
                    ExportedSeperator = table.Column<string>(maxLength: 10, nullable: true),
                    ExportedWithHeader = table.Column<bool>(nullable: false),
                    UploadBatchId = table.Column<string>(nullable: true),
                    UploadedDateTime = table.Column<DateTime>(nullable: true),
                    UploadAtMachine = table.Column<string>(maxLength: 250, nullable: true),
                    UploadAtAbsoluteDirectroy = table.Column<string>(maxLength: 250, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dwfs_FileLog", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Dwfs_ProcessLog",
                schema: "ROSATEST",
                columns: table => new
                {
                    Id = table.Column<string>(maxLength: 40, nullable: false),
                    CreatedBy = table.Column<string>(maxLength: 100, nullable: true),
                    CreatedDateTime = table.Column<DateTime>(nullable: true),
                    UpdatedBy = table.Column<string>(maxLength: 100, nullable: true),
                    UpdatedDateTime = table.Column<DateTime>(nullable: true),
                    DataProcessStatus = table.Column<int>(nullable: false),
                    ProcessName = table.Column<string>(maxLength: 150, nullable: true),
                    StartDateTime = table.Column<DateTime>(nullable: true),
                    EndDateTime = table.Column<DateTime>(nullable: true),
                    BatchId = table.Column<string>(maxLength: 40, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Dwfs_ProcessLog", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Dwfs_FileLog_DataProcess",
                schema: "ROSATEST",
                table: "Dwfs_FileLog",
                column: "DataProcessStatus");

            migrationBuilder.CreateIndex(
                name: "IX_Dwfs_FileLog_ExportDate",
                schema: "ROSATEST",
                table: "Dwfs_FileLog",
                column: "ExportedDateTime");

            migrationBuilder.CreateIndex(
                name: "IX_Dwfs_FileLog_DataDate",
                schema: "ROSATEST",
                table: "Dwfs_FileLog",
                column: "FileDataDate");

            migrationBuilder.CreateIndex(
                name: "IX_Dwfs_FileLog_UploadBatchId",
                schema: "ROSATEST",
                table: "Dwfs_FileLog",
                column: "UploadBatchId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Dwfs_FileLog",
                schema: "ROSATEST");

            migrationBuilder.DropTable(
                name: "Dwfs_ProcessLog",
                schema: "ROSATEST");
        }
    }
}
