﻿using Quartz;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Cons.Sched.Core.Jobs
{
    public abstract class AcidProcessJob : IJob
    {
        public Task Execute(IJobExecutionContext context)
        {
            var task = new Task(() => {
                IList<Exception> errors = new List<Exception>();

                try
                {
                    ExecuteAcidProcesses(context, ref errors);
                }
                catch (Exception ex)
                {
                    errors.Add(ex);
                }

                if (errors.Any())
                {
                    foreach (Exception error in errors)
                    {
                        Log.Error(error, error.Message);
                    }
                    throw new Exception(String.Format("Find previous {0} errors.", errors.Count));
                }
            });
            task.Start();
            task.Wait();
            return task;
        }

        protected abstract void ExecuteAcidProcesses(IJobExecutionContext context, ref IList<Exception> errors);
    }
}
