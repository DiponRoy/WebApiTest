﻿using Dwfs.Core.Setting;
using Dwfs.Core.Utility;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cons.Sched.Core
{
    public class SerilogConfig
    {
        public static LoggerConfiguration Builder(string fileName)
        {
            string errorDirectory = AppConfig.Instance.Config["serilog:errorDir:schedulers"];
            string dayWiseFileName = "{Date}_" + String.Format("{0}.txt", fileName);
            var filePath = FileSystemHelper.CombineFile(errorDirectory, dayWiseFileName);

            var builder = new LoggerConfiguration()
               .MinimumLevel
               .Information()
               .WriteTo.RollingFile(filePath, LogEventLevel.Information);
            return builder;
        }

        public static Logger Build(string fileName)
        {
            var logger = Builder(fileName).CreateLogger();
            return logger;
        }

        public static void Configure(string name)
        {
            Log.Logger = Build(name);
        }
    }
}
