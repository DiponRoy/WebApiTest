﻿/*
 * https://stackoverflow.com/questions/23697467/returning-datatable-using-entity-framework
 */


using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace Db.Dwfs.Core
{
    /// <summary>
    /// Ef db context helper
    /// </summary>
    public static class DbContextExtensions
    {
     
        /// <summary>
        /// Create date table form Ef DbContext
        /// </summary>
        /// <param name="context">EF Db context</param>
        /// <param name="sqlQuery">Query</param>
        /// <returns>Result as DateTable</returns>
        public static DataTable DataTable(DbContext context, string sqlQuery, List<DbParameter> parameters = null)
        {
            DbProviderFactory dbFactory = DbProviderFactories.GetFactory(context.Database.GetDbConnection());

            using (var cmd = dbFactory.CreateCommand())
            {
                cmd.Connection = context.Database.GetDbConnection();
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = sqlQuery;
                if (parameters != null)
                {
                    foreach (var item in parameters)
                    {
                        cmd.Parameters.Add(item);
                    }
                }
                using (DbDataAdapter adapter = dbFactory.CreateDataAdapter())
                {
                    adapter.SelectCommand = cmd;

                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    return dt;
                }
            }
        }
    }
}