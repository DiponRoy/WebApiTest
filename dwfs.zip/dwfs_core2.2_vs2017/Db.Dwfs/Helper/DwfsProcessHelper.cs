﻿using Db.Dwfs.Core;
using Db.Dwfs.Core.Status;
using Db.Dwfs.Core.Table;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Db.Dwfs.Helper
{
    public class DwfsProcessHelper
    {
        public IDwfsLogDbContext DbContext { get; private set; }
        public string ProcessName { get; }
        public string UserName { get; }
        public string BatchId { get;  }

        private DwfsProcessLog log;

        public DwfsProcessLog Batch()
        {
            return log;
        }

        public DwfsProcessHelper(IDwfsLogDbContext db, string processName, string userName, string batchId)
        {
            Set(db);
            ProcessName = processName;
            UserName = userName;
            BatchId = batchId;
        }

        public void Set(IDwfsLogDbContext db)
        {
            DbContext = db;
        }

        /// <summary>
        /// Create a log as started
        /// </summary>
        /// <returns></returns>
        public DwfsProcessLog AddAsInProgress()
        {
            DwfsDataProcessStatus status = DwfsDataProcessStatus.InProgress;
            log = Add(status);
            return log;
        }

        /// <summary>
        /// Create a log as skiped
        /// </summary>
        /// <returns></returns>
        public DwfsProcessLog AddAsSkiped()
        {
            DwfsDataProcessStatus status = DwfsDataProcessStatus.ProcessSkiped;
            log = Add(status);
            log.EndDateTime = DateTime.Now;
            return log;
        }


        private DwfsProcessLog Add(DwfsDataProcessStatus status)
        {
            var entity = new DwfsProcessLog()
            {
                Id = Guid.NewGuid().ToString(),
                ProcessName = ProcessName,
                StartDateTime = DateTime.Now,
                DataProcessStatus = (int)status,
                CreatedBy = UserName,
                CreatedDateTime = DateTime.Now,
                BatchId = BatchId
            };
            DbContext.ProcessLogs.Add(entity);
            return entity;
        }

        /// <summary>
        /// Log current process as successfully finished
        /// </summary>
        public void Done()
        {
            Update(log, DwfsDataProcessStatus.ProcessDone);
        }

        /// <summary>
        /// Log current process as not successfully finished
        /// </summary>
        public void Fail()
        {
            Update(log, DwfsDataProcessStatus.ProcessFail);
        }

        private void Update(DwfsProcessLog batch, DwfsDataProcessStatus status)
        {
            DbContext.ProcessLogs.Attach(batch);
            batch.EndDateTime = DateTime.Now;
            batch.DataProcessStatus = (int)status;
            batch.UpdatedBy = UserName;
            batch.UpdatedDateTime = DateTime.Now;
            DbContext.Entry(batch).State = EntityState.Modified;
        }
    }
}
