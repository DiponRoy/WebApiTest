﻿using Db.Dwfs.Core;
using Microsoft.EntityFrameworkCore;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;

namespace Db.Dwfs.Oracle
{
    public abstract class DwfsSourceOracleDbContext : DwfsSourceDbContext
    {
        protected override DbParameter DbParameter(string parameterName, DateTime parameterValue)
        {
            OracleParameter param = new OracleParameter(parameterName, OracleDbType.Date, parameterValue, ParameterDirection.Input);
            return param;
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseOracle(ConnectionString());
        }
    }
}
