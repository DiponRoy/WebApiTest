﻿using Db.Dwfs.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Db.Dwfs.Oracle
{
    public abstract class DwfsLogOracleDbContext : DwfsLogDbContext
    {
        protected string GetConnectionUserId()
        {
            try
            {
                string connectionString = ConnectionString();
                var userName = connectionString.Split(";")
                    .First(x => x.Replace(" ", "").ToLower().StartsWith("userid="))
                    .Split("=").Last().Trim();
                return userName;
            }
            catch (Exception ex)
            {
                throw new Exception("Error to get oracle user name from connection string.", ex);
            }
        }

        /// <summary>
        /// Table mappings
        /// </summary>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            string schema = GetConnectionUserId();
            modelBuilder.HasDefaultSchema(schema);
            base.OnModelCreating(modelBuilder); /*important to create indexes*/
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            string schema = GetConnectionUserId();
            /*
             * UseOracleSQLCompatibility("11") important for skip take
             * https://community.oracle.com/thread/4290877
             * https://docs.oracle.com/en/database/oracle/oracle-data-access-components/19.3/odpnt/EFCoreAPI.html#GUID-770CD8EA-F963-48A5-A679-CAF471A4DB1A
             * 
             * Custom migration table
             * https://docs.microsoft.com/en-us/ef/core/managing-schemas/migrations/history-table
             */
            optionsBuilder.UseOracle(ConnectionString(), d => {
                d.MigrationsHistoryTable(MigrationTableName, schema);
                d.UseOracleSQLCompatibility("11");
            });
        }
    }
}
