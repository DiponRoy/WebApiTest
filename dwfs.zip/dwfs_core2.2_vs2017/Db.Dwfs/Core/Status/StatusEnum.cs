﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Db.Dwfs.Core.Status
{
    public enum DwfsFileLogDataProcessStatus
    {
        UploadFail = -4,
        FileCreateFail = -2,
        None = 0,
        FileCreateInProgress = 1,
        FileCreateDone = 2,
        UploadInProgress = 3,
        UploadDone = 4
    }

    public enum DwfsDataProcessStatus
    {
        ProcessFail = -2,
        ProcessSkiped = -1,
        None = 0,
        InProgress = 1,
        ProcessDone = 2,
    }
}
