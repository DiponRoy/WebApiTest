﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Db.Dwfs.Core.Status
{
    public class ProcessNames
    {
        public const string CreateDateWiseFile = "CreateDateWiseFile";
        public const string UploadDateWiseFile = "UploadCreatedFile";
    }
}
