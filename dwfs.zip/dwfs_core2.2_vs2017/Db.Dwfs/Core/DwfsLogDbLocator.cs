﻿using Db.Dwfs.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Db.Dwfs
{

    public interface IDwfsLogDbLocator : IDisposable
    {
        IDwfsLogDbContext Current { get; }
        void Reset();
    }

    /*https://stackoverflow.com/questions/5643610/is-there-a-way-to-reset-a-dbcontext-without-disposing-and-reinstantiating-it*/
    public class DwfsLogDbLocator<TContext> : IDwfsLogDbLocator where TContext : DbContext, IDwfsLogDbContext, new()
    {
        public IDwfsLogDbContext Current { get; protected set; }

        public DwfsLogDbLocator()
        {
            Current = Create();
        }

        public virtual void Reset()
        {
            Dispose();
            Current = Create();
        }

        public virtual void Dispose()
        {
            if (Current != null)
            {
                Current.Dispose();
            }
            Current = null;
        }

        protected virtual IDwfsLogDbContext Create()
        {
            return new TContext();
        }
    }
}
