﻿using Db.Dwfs.Core.Table;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;

namespace Db.Dwfs.Core
{
    public interface IDwfsSourceDbContext : IDisposable
    {
        DataTable Data(string pramitarizedSql, string dateParamiterName, DateTime date);
    }

    public abstract class DwfsSourceDbContext : DbContext, IDwfsSourceDbContext
    {

        protected abstract DbParameter DbParameter(string parameterName, DateTime parameterValue);

        public DataTable Data(string pramitarizedSql, string dateParamiterName, DateTime date)
        {
            DbParameter param = DbParameter(dateParamiterName, date);
            return DbContextExtensions.DataTable(this, pramitarizedSql, new List<DbParameter>() { param });
        }

        protected abstract string ConnectionString();
    }
}
