﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Toolbelt.ComponentModel.DataAnnotations.Schema;

namespace Db.Dwfs.Core.Table
{
    [Table("Dwfs_FileLog")]
    public class DwfsFileLog : ICreateUpdateLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [MaxLength(40)]
        public string Id { get; set; }
        [MaxLength(100)]
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        [MaxLength(100)]
        public string UpdatedBy { get; set; }
        public DateTime? UpdatedDateTime { get; set; }
        [Index("IX_Dwfs_FileLog_DataProcess")]
        public int DataProcessStatus { get; set; }
        [Required]
        [Index("IX_Dwfs_FileLog_DataDate")]
        public DateTime? FileDataDate { get; set; }
        [MaxLength(150)]
        public string FileName { get; set; }                    /*file.text*/
        public int FileDataColumnCount { get; set; }
        public int FileDataRowCount { get; set; }               /*with out header*/
        [MaxLength(40)]
        public string ExportBatchId { get; set; }
        [Index("IX_Dwfs_FileLog_ExportDate")]
        public DateTime? ExportedDateTime { get; set; }
        /*Db max size*/
        public string ExportSqlQuery { get; set; }
        [MaxLength(250)]
        public string ExportAtMachine { get; set; }
        [MaxLength(250)]
        public string ExportAtAbsoluteDirectroy { get; set; }           /*c:\\temp\\Scb*/
        [MaxLength(10)]
        public string ExportedSeperator { get; set; }
        public bool ExportedWithHeader { get; set; }
        [Index("IX_Dwfs_FileLog_UploadBatchId")]
        public string UploadBatchId { get; set; }
        public DateTime? UploadedDateTime { get; set; }
        [MaxLength(250)]
        public string UploadAtMachine { get; set; }
        [MaxLength(250)]
        public string UploadAtAbsoluteDirectroy { get; set; }
    }
}
