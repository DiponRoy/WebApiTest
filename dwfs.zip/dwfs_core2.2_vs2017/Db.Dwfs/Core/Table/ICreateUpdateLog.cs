﻿using System;

namespace Db.Dwfs.Core.Table
{
    public interface ICreateUpdateLog 
    { 
        string CreatedBy { get; set; }
        DateTime? CreatedDateTime { get; set; }
        string UpdatedBy { get; set; }
        DateTime? UpdatedDateTime { get; set; }
    }
}
