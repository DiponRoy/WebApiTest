﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;
using Toolbelt.ComponentModel.DataAnnotations.Schema;

namespace Db.Dwfs.Core.Table
{

    [Table("Dwfs_ProcessLog")]
    public class DwfsProcessLog : ICreateUpdateLog
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        [MaxLength(40)]
        [Column("Id")]
        public string Id { get; set; }
        [MaxLength(100)]
        [Column("CreatedBy")]
        public string CreatedBy { get; set; }
        [Column("CreatedDateTime")]
        public DateTime? CreatedDateTime { get; set; }
        [MaxLength(100)]
        [Column("UpdatedBy")]
        public string UpdatedBy { get; set; }
        [Column("UpdatedDateTime")]
        public DateTime? UpdatedDateTime { get; set; }
        [Column("DataProcessStatus")]
        public int DataProcessStatus { get; set; }
        [Column("ProcessName")]
        [MaxLength(150)]
        public string ProcessName { get; set; }
        [Column("StartDateTime")]
        public DateTime? StartDateTime { get; set; }
        [Column("EndDateTime")]
        public DateTime? EndDateTime { get; set; }
        [MaxLength(40)]
        [Column("BatchId")]
        public string BatchId { get; internal set; }
    }
}
