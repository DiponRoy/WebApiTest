﻿using Db.Dwfs.Core;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Db.Dwfs
{

    public interface IDwfsSourceDbLocator : IDisposable
    {
        IDwfsSourceDbContext Current { get; }
        void Reset();
    }

    /*https://stackoverflow.com/questions/5643610/is-there-a-way-to-reset-a-dbcontext-without-disposing-and-reinstantiating-it*/
    public class DwfsSourceDbLocator<TContext> : IDwfsSourceDbLocator where TContext : DbContext, IDwfsSourceDbContext, new()
    {
        public IDwfsSourceDbContext Current { get; protected set; }

        public DwfsSourceDbLocator()
        {
            Current = Create();
        }

        public virtual void Reset()
        {
            Dispose();
            Current = Create();
        }

        public virtual void Dispose()
        {
            if (Current != null)
            {
                Current.Dispose();
            }
            Current = null;
        }

        protected virtual IDwfsSourceDbContext Create()
        {
            return new TContext();
        }
    }
}
