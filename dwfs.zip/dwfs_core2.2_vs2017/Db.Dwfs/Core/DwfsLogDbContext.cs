﻿using Db.Dwfs.Core.Table;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Toolbelt.ComponentModel.DataAnnotations;

namespace Db.Dwfs.Core
{

    public interface IDwfsLogDbContext : IDisposable
    {
        string MigrationTableName { get; }
        DbSet<DwfsProcessLog> ProcessLogs { get; set; }
        DbSet<DwfsFileLog> FileLogs { get; set; }

        int SaveChanges();
        EntityEntry<TEntity> Entry<TEntity>(TEntity entity) where TEntity : class;
    }

    public abstract class DwfsLogDbContext : DbContext, IDwfsLogDbContext
    {
        public string MigrationTableName
        {
           get
            {
                return "Dwfs_EFMigrationsHistory"; /*default name __EFMigrationsHistory*/
            }
        }  

        public DbSet<DwfsProcessLog> ProcessLogs { get; set; }
        public DbSet<DwfsFileLog> FileLogs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            /*https://github.com/jsakamoto/EntityFrameworkCore.IndexAttribute*/
            modelBuilder.BuildIndexesFromAnnotations();
        }

        protected abstract string ConnectionString();
    }
}
