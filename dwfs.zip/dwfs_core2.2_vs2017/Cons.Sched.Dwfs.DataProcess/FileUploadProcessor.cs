﻿using System;
using System.Collections.Generic;
using System.Linq;
using Db.Dwfs;
using Db.Dwfs.Core;
using Db.Dwfs.Core.Status;
using Db.Dwfs.Core.Table;
using Db.Dwfs.Helper;
using Dwfs.Core.Utility;
using FileSystem.Core.Remote;
using Microsoft.EntityFrameworkCore;

namespace Cons.Sched.Dwfs.DataProcess
{

    public class FileUploadProcessor
    {
        private readonly int BatchSize;
        private readonly IDwfsLogDbLocator DbLocator;
        private readonly IRemoteFileSystemContext Remote;
        private readonly AppSetting AppSetting;
        private readonly string RemoteAbsoluteDirectory;

        private string _batchId;
        private string _userName;
        private IDwfsLogDbContext _db;
        private DwfsProcessHelper _processLog;


        public FileUploadProcessor(IDwfsLogDbLocator dbLocator, IRemoteFileSystemContext remote, AppSetting appSetting, string remoteDirectory)
        {
            DbLocator = dbLocator;
            SetDb(DbLocator);
            Remote = remote;

            AppSetting = appSetting;
            RemoteAbsoluteDirectory = remoteDirectory;

            BatchSize = AppSetting.FileCreateBatchSize;
        }

        private void ResetDb(IDwfsLogDbLocator dbLocator)
        {
            SetDb(dbLocator);
            _processLog.Set(_db);
        }

        private void SetDb(IDwfsLogDbLocator dbLocator)
        {
            _db = dbLocator.Current;
        }

        protected List<int> EligibleCandidateStatus()
        {
            return new List<int>()
            {
                (int)DwfsFileLogDataProcessStatus.FileCreateDone,
                (int)DwfsFileLogDataProcessStatus.UploadFail
            };
        }

        public bool Validate(DwfsFileLog file, out string localPath, out string remotePath, out List<string> errors)
        {
            localPath = "";
            remotePath = "";
            errors = new List<string>();

            /*local file check*/
            string localFilePath = FileSystemHelper.CombineFile(file.ExportAtAbsoluteDirectroy, file.FileName);
            if (!FileSystemHelper.FileExists(localFilePath))
            {
                errors.Add(string.Format("local file '{0}' not found", localFilePath));
                return false;
            }
            /*remote directory check*/
            string remoteDirectory = FtpHelper.FtpDirectory(RemoteAbsoluteDirectory);
            if (!Remote.DirectoryExists(remoteDirectory))
            {
                errors.Add(string.Format("Remote directory '{0}' not found", remoteDirectory));
                return false;
            }
            /*remote file check*/
            string remotefilePath = FtpHelper.CombineFile(remoteDirectory, file.FileName);
            if (Remote.FileExists(remotefilePath))
            {
                errors.Add(string.Format("'{0}' file already exists at remote", remotefilePath));
                return false;
            }

            localPath = localFilePath;
            remotePath = remotefilePath;
            return true;
        }

        internal void Begain(Guid batchId, string userName, ref IList<Exception> errors)
        {
            _batchId = batchId.ToString();
            _userName = userName;
            _processLog = new DwfsProcessHelper(_db, ProcessNames.UploadDateWiseFile, _userName, _batchId);

            try
            {
                if (!AppSetting.ShouldUploadFile)
                {
                    _processLog.AddAsSkiped();
                    _db.SaveChanges();
                    return;
                }


                _processLog.AddAsInProgress();
                _db.SaveChanges();

                UploadFiles();

                _processLog.Done();
                _db.SaveChanges();
            }
            catch (Exception ex)
            {
                errors.Add(ex);
                _processLog.Fail();
                _db.SaveChanges();
            }
        }

        private void UploadFiles()
        {
            List<DwfsFileLog> files;
            while (CandidateFiles(out files))
            {
                foreach (var item in files)
                {
                    /*connect to ftp*/
                    if (!Remote.IsConnected())
                    {
                        Remote.Connect();
                        Remote.SetRootAsWorkingDirectory(); /*SetRootAsWorkingDirectory*/
                    }

                    /*file upload in progress*/
                    item.DataProcessStatus = (int)DwfsFileLogDataProcessStatus.UploadInProgress;
                    item.UploadAtAbsoluteDirectroy = RemoteAbsoluteDirectory;
                    item.UploadAtMachine = Remote.ServerDetails();
                    item.UploadBatchId = _batchId;
                    item.UpdatedBy = _userName;
                    item.UpdatedDateTime = DateTime.Now;
                    _db.SaveChanges();

                    try
                    {
                        /*validation*/
                        string localFilePath;
                        string remoteFilePath;
                        List<string> errors;
                        if (!Validate(item, out localFilePath, out remoteFilePath, out errors))
                        {
                            throw new Exception(String.Join(" ", errors.ToArray()));
                        }

                        /*success*/
                        Remote.UploadFile(localFilePath, remoteFilePath);
                        item.UploadedDateTime = DateTime.Now;
                        item.DataProcessStatus = (int)DwfsFileLogDataProcessStatus.UploadDone;
                    }
                    catch (Exception ex)
                    {
                        /*fail*/
                        item.DataProcessStatus = (int)DwfsFileLogDataProcessStatus.UploadFail;
                        throw new Exception(String.Format("File upload fail for Id:{0}", item.Id), ex);
                    }
                    finally
                    {
                        item.UpdatedBy = _userName;
                        item.UpdatedDateTime = DateTime.Now;
                        _db.SaveChanges();
                    }
                }

                /*recreate db*/
                DbLocator.Reset();
                ResetDb(DbLocator);
            }
        }

        protected bool CandidateFiles(out List<DwfsFileLog> Files)
        {
            List<int> status = EligibleCandidateStatus();
            var items = _db.FileLogs
                .Where(x =>
                    status.Contains(x.DataProcessStatus)
                    && (x.UploadBatchId == null || !x.UploadBatchId.Equals(_batchId))
                )
                .OrderByDescending(x => x.DataProcessStatus)
                .Take(BatchSize);
            Files = items.ToList();
            return Files.Any();
        }
    }    
}
