﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Text;
using System.Threading.Tasks;
using Cons.Sched.Core;
using Cons.Sched.Core.Jobs;
using Cons.Sched.Dwfs.DataProcess;
using Cons.Sched.Dwfs.DataProcess.Db;
using Cons.Sched.Dwfs.DataProcess.Remote;
using Db.Dwfs;
using Dwfs.Core;
using Dwfs.Core.Setting;
using FileSystem.Core.Local;
using FileSystem.Core.Remote;
using Quartz;
using Sched.Core.Schedule;

namespace Cons.Sched.DataProcess
{
    [DisallowConcurrentExecution] /*impt: no multiple instances executed concurrently*/
    public class DataProcessJob : AcidProcessJob, IJob
    {
        protected override void ExecuteAcidProcesses(IJobExecutionContext context, ref IList<Exception> errors)
        {
            DwfsSetting settings = DwfsSetting.Instance;
            Guid batchId = Guid.NewGuid();
            string userName = SchedulerNames.SftpDwfsDataProcess;

            /*skip*/
            if (settings.AppSetting.SchedulerShouldStopOnTextRun())
            {
                return;
            }


            /*select db*/
            IDwfsSourceDbLocator sourceDblocator = DbLocatorFactory.SourceDb(settings.DbSetting.SourceDbType);
            IDwfsLogDbLocator logDblocator = DbLocatorFactory.LogDb(settings.DbSetting.LogDbType);

            /*create files*/
            new FileCreateProcessor(logDblocator, sourceDblocator, settings.AppSetting, settings.SourceDbQuery, settings.LocalFileSystem)
                .Begain(batchId, userName, ref errors);

            /*upload files*/
            IRemoteFileSystemContext remoteFileContext = RemoteFactory.Context(settings.RemoteSystem.Type);
            logDblocator.Reset();
            new FileUploadProcessor(logDblocator, remoteFileContext, settings.AppSetting, settings.RemoteSystem.AbsoluteRootDirectory)
                .Begain(batchId, userName, ref errors);

            remoteFileContext.Dispose();
            sourceDblocator.Dispose();
            logDblocator.Dispose();
        }
    }

    public class DataProcessSchedule : Schedule
    {
        public readonly string CronExpression;
        public DataProcessSchedule(IScheduler scheduler) : base(scheduler, "DataProcessSchedule")
        {
            /*https://blog.bitscry.com/2017/05/30/appsettings-json-in-net-core-console-app/*/
            //var value = AppConfig.Instance.Config["scheduler:cronExpression:value"];
            var value = DwfsSetting.Instance.AppSetting.SchedulerCronExpression;
            CronExpression = value;
        }

        public void Start()
        {
            JobBuilder jobBuilder = JobBuilder.Create<DataProcessJob>();
            TriggerBuilder triggerBuilder = TriggerBuilder.Create().WithCronSchedule(CronExpression);
            ScheduleTask(jobBuilder, triggerBuilder);
            AttachJobListener();
        }
    }

    public class DataProcessScheduleContext : ScheduleContext
    {
        private DataProcessSchedule _schedule;

        public DataProcessSchedule Schedule
        {
            get
            {
                _schedule = _schedule ?? new DataProcessSchedule(Scheduler);
                return _schedule;
            }
        }

        public DataProcessScheduleContext()
        {
            Props = new NameValueCollection
            {
                {"quartz.scheduler.instanceName", nameof(DataProcessScheduleContext)}
            };
            Task.Run(async () => { await Start(); }).Wait();
        }
    }
}
