﻿using Db.Dwfs;
using Db.Dwfs.Core;
using Db.Dwfs.Core.Status;
using Db.Dwfs.Core.Table;
using Db.Dwfs.Helper;
using Dwfs.Core.Setting;
using Dwfs.Core.Utility;
using FileSystem.Core.Local;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;

namespace Cons.Sched.Dwfs.DataProcess
{
    public class FileCreateProcessor
    {
        private readonly int BatchSize;
        private readonly string LocalServerDetails;
        private readonly IDwfsLogDbLocator LogDbLocator;
        private readonly AppSetting AppSetting;
        private readonly SourceDbQuerySetting QuerySetting;
        private readonly LocalFileSystemSetting FileSetting;

        private IDwfsSourceDbContext _sourceDbContext;
        private IDwfsLogDbContext _logDbContext;
        private string _batchId;
        private string _userName;
        private DwfsProcessHelper _processLog;


        public FileCreateProcessor(IDwfsLogDbLocator dbLogLocator, IDwfsSourceDbLocator dbSourceLocator, AppSetting appSetting, SourceDbQuerySetting querySetting, LocalFileSystemSetting fileSetting)
        {
            LogDbLocator = dbLogLocator;
            SetDb(LogDbLocator);
            _sourceDbContext = dbSourceLocator.Current;

            AppSetting = appSetting;
            QuerySetting = querySetting;
            FileSetting = fileSetting;
            LocalServerDetails = LocalMachineHelper.ServerDetails();

            BatchSize = AppSetting.FileUploadBatchSize;
        }

        private void ResetDb(IDwfsLogDbLocator dbLocator)
        {
            SetDb(dbLocator);
            _processLog.Set(_logDbContext);
        }

        private void SetDb(IDwfsLogDbLocator dbLocator)
        {
            _logDbContext = dbLocator.Current;
        }

        internal void Begain(Guid batchId, string userName, ref IList<Exception> errors)
        {
            _batchId = batchId.ToString();
            _userName = userName;
            _processLog = new DwfsProcessHelper(_logDbContext, ProcessNames.UploadDateWiseFile, _userName, _batchId);

            try
            {
                if (!AppSetting.ShouldCreateFile)
                {
                    _processLog.AddAsSkiped();
                    _logDbContext.SaveChanges();
                    return;
                }


                FileSystemHelper.CreateDirectoryIfNotExists(FileSetting.FileCreateAbsoluteDirectory);
                _processLog.AddAsInProgress();
                _logDbContext.SaveChanges();

                CreateFiles();

                _processLog.Done();
                _logDbContext.SaveChanges();
            }
            catch (Exception ex)
            {
                errors.Add(ex);
                _processLog.Fail();
                _logDbContext.SaveChanges();
                throw;
            }
        }

        private void CreateFiles()
        {
            foreach (var dates in CandidateDates())
            {
                foreach (DateTime targetDate in dates)
                {
                    if (IsFileAlreadyCreated(targetDate))
                    {
                        continue;
                    }

                    DataTable dataTable = _sourceDbContext.Data(QuerySetting.ParameterizedQuery, QuerySetting.DateParameterName, targetDate);
                    if (AvoidCreatingEmptyFile(dataTable))
                    {
                        continue;
                    }

                    CreateFile(targetDate, dataTable);
                }

                /*recreate db*/
                LogDbLocator.Reset();
                ResetDb(LogDbLocator);
            }
        }

        private bool AvoidCreatingEmptyFile(DataTable dataTable)
        {
            bool isEmptyFile = dataTable.Columns.Count == 0 || dataTable.Rows.Count == 0;
            bool value = isEmptyFile && FileSetting.AvoidCreatingEmptyFile;
            return value;
        }

        private void CreateFile(DateTime targetDate, DataTable dataTable)
        {
            string fileName = FileSetting.FileName(targetDate, DateTime.Now);
            bool includeHeader = FileSetting.IncludeHeader;
            string seperator = FileSetting.Seperator;
            DwfsFileLog item = new DwfsFileLog()
            {
                Id = Guid.NewGuid().ToString(),
                CreatedBy = _userName,
                CreatedDateTime = DateTime.Now,
                DataProcessStatus = (int)DwfsFileLogDataProcessStatus.FileCreateInProgress,
                FileDataDate = targetDate,
                FileName = fileName,
                FileDataColumnCount = dataTable.Columns.Count,
                FileDataRowCount = dataTable.Rows.Count,
                ExportSqlQuery = QuerySetting.ParameterizedQuery,
                ExportAtMachine = LocalServerDetails,
                ExportAtAbsoluteDirectroy = FileSetting.FileCreateAbsoluteDirectory,
                ExportedWithHeader = includeHeader,
                ExportedSeperator = seperator,
                ExportBatchId = _batchId,

                ExportedDateTime = null
            };
            _logDbContext.FileLogs.Add(item);
            _logDbContext.SaveChanges();

            string filePath = string.Empty;
            List<string> errors;
            try
            {
                /*validation*/
                if (!Validate(item, out filePath, out errors))
                {
                    throw new Exception(String.Join(" ", errors.ToArray()));
                }

                /*success*/
                File.WriteAllText(filePath, DataTableHelper.DataTableToFileContent(dataTable, seperator, includeHeader, FileSetting.NullColumnValue, FileSetting.TrimColumnsValue));
                item.DataProcessStatus = (int)DwfsFileLogDataProcessStatus.FileCreateDone;
                item.ExportedDateTime = DateTime.Now;
            }
            catch (Exception ex)
            {
                /*fail*/
                item.DataProcessStatus = (int)DwfsFileLogDataProcessStatus.FileCreateFail;
                FileSystemHelper.DeleteFileIfExists(filePath);
                throw new Exception(String.Format("File create fail for Id:{0}", item.Id), ex);
            }
            finally
            {
                item.UpdatedBy = _userName;
                item.UpdatedDateTime = DateTime.Now;
                _logDbContext.SaveChanges();
            }
        }

        private bool Validate(DwfsFileLog item, out string filePath, out List<string> errors)
        {
            filePath = string.Empty;
            errors = new List<string>();

            /*directroy check*/
            string directory = item.ExportAtAbsoluteDirectroy;
            if (!FileSystemHelper.DirectoryExists(directory))
            {
                errors.Add(string.Format("Directory '{0}' not found", directory));
                return false;
            }
            /*file check*/
            filePath = FileSystemHelper.CombineFile(directory, item.FileName);
            if (FileSystemHelper.FileExists(filePath))
            {
                errors.Add(string.Format("File found at '{0}'", filePath));
                return false;
            }

            return true;                
        }

        private bool IsFileAlreadyCreated(DateTime targetDate)
        {
            bool value = _logDbContext.FileLogs.Any(x => x.FileDataDate == targetDate && x.ExportedDateTime != null);
            return value;
        }

        private IEnumerable<List<DateTime>> CandidateDates()
        {
            List<DateTime> items = new List<DateTime>();
            foreach (var date in QuerySetting.TargetDates())
            {
                items.Add(date);
                if (items.Count % BatchSize == 0)
                {
                    yield return items;
                    items = new List<DateTime>();
                }
            }

            if (items.Count > 1)
            {
                yield return items;
            }
        }
    }
}
