﻿using Cons.Sched.Core;
using Cons.Sched.DataProcess;
using Dwfs.Core;
using Dwfs.Core.Setting;
using Serilog;
using System;

namespace Cons.Sched.Dwfs.DataProcess
{
    class Program
    {
        private static DataProcessScheduleContext _scheduleContext;

        static void Main(string[] args)
        {
            try
            {
                /*configs*/
                var setting = AppConfig.Instance;
                Log.Logger = SerilogConfig.Build(SchedulerNames.SftpDwfsDataProcess);

                /*scheduler*/
                _scheduleContext = new DataProcessScheduleContext();
                _scheduleContext.Schedule.TaskStarted += BeforeStart;
                _scheduleContext.Schedule.TaskExecuted += AfterEndAsync;
                _scheduleContext.Schedule.Start();
                Estimated(_scheduleContext.Schedule.NextFireTime());
            }
            catch (Exception ex)
            {
                Console.WriteLine("\n" + "Error to Run!");
                Log.Error(ex, ex.Message);
            }

            Console.Read();
        }

        private static void Estimated(DateTime? dateTime)
        {
            string msg = "Estimated: ";
            if (dateTime != null)
            {
                msg += ((DateTime)dateTime).ToString("dd-MMM-yyyy hh:mm:ss tt");
            }
            Console.Write("\n" + msg);
        }

        private static void BeforeStart()
        {
            Console.Write("\t" + "Started: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt"));
        }

        private static void AfterEndAsync(Exception exception)
        {
            Console.Write("\t" + "Ended: " + DateTime.Now.ToString("dd-MMM-yyyy hh:mm:ss tt"));
            string status = exception != null ? "Error" : "Success";
            Console.Write("\t" + "Result: " + status);
            Estimated(_scheduleContext.Schedule.NextFireTime());

            if (exception != null)
            {
                Log.Error(exception, exception.Message);
            }
        }
    }

}
