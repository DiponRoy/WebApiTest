﻿using Cons.Sched.Core;
using Db.Dwfs;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess.Db
{
    public class DbLocatorFactory
    {
        public static IDwfsLogDbLocator LogDb(string type)
        {
            type = type.Trim().ToLower();
            IDwfsLogDbLocator locator = null;
            switch (type)
            {
                case "oracle":
                    locator = new DwfsLogDbLocator<OracleLogDb>();
                    break;
                default:
                    throw new Exception(String.Format(@"Type:{0} is unknown to load log db locator", type));
            }

            return locator;
        }

        public static IDwfsSourceDbLocator SourceDb(string type)
        {
            type = type.Trim().ToLower();
            IDwfsSourceDbLocator locator = null;
            switch (type)
            {
                case "oracle":
                    locator = new DwfsSourceDbLocator<OracleSourceDb>();
                    break;
                default:
                    throw new Exception(String.Format(@"Type:{0} is unknown to load source db locator", type));
            }
            return locator;
        }
    }
}
