﻿using Cons.Sched.Dwfs.DataProcess;
using Db.Dwfs.Core;
using Db.Dwfs.Oracle;
using Dwfs.Core.Setting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess.Db
{
    public class OracleLogDb : DwfsLogOracleDbContext
    {
        protected override string ConnectionString()
        {
            var value = DwfsSetting.Instance.DbSetting.LogDbConnectionString;
            return value;
        }
    }
}
