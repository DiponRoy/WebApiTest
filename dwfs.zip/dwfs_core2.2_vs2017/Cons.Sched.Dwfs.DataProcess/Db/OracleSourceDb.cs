﻿using Cons.Sched.Dwfs.DataProcess;
using Db.Dwfs.Core;
using Db.Dwfs.Oracle;
using Dwfs.Core.Setting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Oracle.ManagedDataAccess.Client;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.IO;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess.Db
{
    public class OracleSourceDb : DwfsSourceOracleDbContext
    {
        protected override string ConnectionString()
        {
            var value = DwfsSetting.Instance.DbSetting.SourceDbConnectionString;
            return value;
        }
    }
}
