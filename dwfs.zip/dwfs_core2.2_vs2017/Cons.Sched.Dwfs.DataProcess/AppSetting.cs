﻿using Dwfs.Core.Setting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess
{
    public class AppSetting
    {
        private IConfigurationRoot _config;
        public string SchedulerCronExpression { get; protected set; }
        public bool ShouldCreateFile { get; protected set; }
        public int FileCreateBatchSize { get; protected set; }
        public bool ShouldUploadFile { get; protected set; }
        public int FileUploadBatchSize { get; protected set; }


        public AppSetting(IConfigurationRoot config)
        {
            _config = config;
            SchedulerCronExpression = _config["scheduler:cronExpression:value"];
            ShouldCreateFile = Convert.ToBoolean(_config["processes:shouldCreateFile"]);
            FileCreateBatchSize = Convert.ToInt32(_config["processes:fileCreateBatchSize"]);
            ShouldUploadFile = Convert.ToBoolean(_config["processes:shouldUploadFile"]);
            FileUploadBatchSize = Convert.ToInt32(_config["processes:fileUploadBatchSize"]);
        }

        public bool SchedulerShouldStopOnTextRun()
        {
            return Convert.ToBoolean(_config["scheduler:shouldStopOnNextRun"]);
        }
    }
}
