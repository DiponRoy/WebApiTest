﻿using Dwfs.Core.Setting;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess
{
    public class DwfsSetting : DwfsRootSetting
    {
        private static DwfsSetting _instance = null;
        public static DwfsSetting Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new DwfsSetting();
                }
                return _instance;
            }
        }

        public AppSetting AppSetting { get; protected set; }


        private DwfsSetting()
        {
            AppSetting = new AppSetting(Config);
        }

        protected override IConfigurationRoot GetConfig()
        {
            return AppConfig.Instance.Config;
        }
    }
}
