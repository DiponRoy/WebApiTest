﻿using Dwfs.Core.Setting;
using Dwfs.Core.Utility;
using FileSystem.Core.Remote;
using Renci.SshNet;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess.Remote
{
    public class SftpRemoteFileSystem : SftpContext
    {
        private string _serverDetails;

        public SftpRemoteFileSystem()
        {
            var setting = DwfsSetting.Instance.RemoteSystem;
            var connectionInfo = new ConnectionInfo(setting.Host, setting.Port, setting.UserName, new PasswordAuthenticationMethod(setting.UserName, setting.Password));
            SftpClient = new SftpClient(connectionInfo);

            _serverDetails = FtpHelper.ServerDetails(setting.Host, setting.Port.ToString(), setting.UserName, setting.Type);
        }

        public override string ServerDetails()
        {
            return _serverDetails;
        }
    }
}
