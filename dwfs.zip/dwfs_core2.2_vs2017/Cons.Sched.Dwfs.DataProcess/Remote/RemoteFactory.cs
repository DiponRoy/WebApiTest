﻿using FileSystem.Core.Remote;
using System;
using System.Collections.Generic;
using System.Text;

namespace Cons.Sched.Dwfs.DataProcess.Remote
{
    class RemoteFactory
    {
        public static IRemoteFileSystemContext Context(string type)
        {
            type = type.Trim().ToLower();
            IRemoteFileSystemContext locator = null;
            switch (type)
            {
                case "sftp":
                    locator = new SftpRemoteFileSystem();
                    break;
                default:
                    throw new Exception(String.Format(@"Type:{0} is unknown remote file system type", type));
            }

            return locator;
        }
    }
}
