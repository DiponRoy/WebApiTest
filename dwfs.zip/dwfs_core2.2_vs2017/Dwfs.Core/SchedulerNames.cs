﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dwfs.Core
{
    public class SchedulerNames
    {
        public static string SftpDwfsDataProcess = "sched.dwfs.dataProcess";     
    }
}
