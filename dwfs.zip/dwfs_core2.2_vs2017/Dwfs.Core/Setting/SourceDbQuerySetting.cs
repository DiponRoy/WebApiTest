﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;

namespace Dwfs.Core.Setting
{
    public class SourceDbQuerySetting
    {
        public int ForDateBuffter { get; private set; }
        public int ToDateBuffter { get; private set; }

        public string DateParameterName { get; private set; }
        public string ParameterizedQuery { get; private set; }

        public SourceDbQuerySetting(IConfigurationRoot config)
        {
            //https://stackoverflow.com/questions/46809679/how-net-core-configutation-files-work
            ForDateBuffter = Convert.ToInt32(config["SourceDbQuery:ForDateBuffter"]);
            ToDateBuffter = Convert.ToInt32(config["SourceDbQuery:ToDateBuffter"]);
            DateParameterName = config["SourceDbQuery:DateParameterName"];
            ParameterizedQuery = config["SourceDbQuery:ParameterizedQuery"];
        }

        public List<DateTime> TargetDates()
        {
            List<DateTime> targetDates = new List<DateTime>();
            for (var dt = DateTime.Now.AddDays(ForDateBuffter); dt <= DateTime.Now.AddDays(ToDateBuffter); dt = dt.AddDays(1))
            {
                targetDates.Add(dt.Date);
            }
            return targetDates;
        }
    }
}
