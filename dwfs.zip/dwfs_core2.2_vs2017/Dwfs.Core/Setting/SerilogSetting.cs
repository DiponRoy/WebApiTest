﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Dwfs.Core.Setting
{
    public class SerilogSetting
    {
        public string SchedulersPath { get; private set; }

        public SerilogSetting()
        {
            SchedulersPath = AppConfig.Instance.Config["serilog:errorDir:schedulers"];
        }
    }
}
