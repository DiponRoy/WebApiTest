﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Dwfs.Core.Setting
{
    public class ConnectionStringSetting
    {
        public string SourceDbType { get; private set; }
        public string SourceDbConnectionString { get; private set; }
        public string LogDbType { get; private set; }
        public string LogDbConnectionString { get; private set; }

        public ConnectionStringSetting(IConfigurationRoot config)
        {
            SourceDbType = config["connectionStrings:sourceDb:dbType"];
            SourceDbConnectionString = config["connectionStrings:sourceDb:dbConnection"];
            LogDbType = config["connectionStrings:logDb:dbType"];
            LogDbConnectionString = config["connectionStrings:logDb:dbConnection"];
        }
    }
}
