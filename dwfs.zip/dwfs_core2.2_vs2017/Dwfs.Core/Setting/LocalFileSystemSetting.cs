﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Dwfs.Core.Setting
{
    public class LocalFileSystemSetting
    {
        public string FileCreateAbsoluteDirectory { get; private set; }
        public bool AvoidCreatingEmptyFile { get; private set; }

      
        public bool IncludeHeader { get; private set; }
        public string Seperator { get; private set; }
        public string NullColumnValue { get; private set; }
        public bool TrimColumnsValue { get; private set; }


        public string FileExtension { get; private set; }
        public string FileDataDateFormat { get; private set; }
        public string FileCreateDateFormat { get; private set; }
        public string FileNameFormat { get; private set; }



        public LocalFileSystemSetting(IConfigurationRoot config)
        {
            FileCreateAbsoluteDirectory = config["localFileSystem:fileCreateAbsoluteDirectory"];
            AvoidCreatingEmptyFile = Convert.ToBoolean(config["localFileSystem:avoidCreatingEmptyFile"]);
           

            Seperator = config["localFileSystem:columnSeperator"];
            IncludeHeader = Convert.ToBoolean(config["localFileSystem:shouldIncludeHeader"]);
            NullColumnValue = config["localFileSystem:nullColumnsDefaultValue"];
            TrimColumnsValue = Convert.ToBoolean(config["localFileSystem:shouldTrimColumnsValue"]);


            FileExtension = config["localFileSystem:fileExtension"].Trim('.');
            FileDataDateFormat = config["localFileSystem:fileDataDateFormat"];
            FileCreateDateFormat = config["localFileSystem:fileCreateDateFormat"];
            FileNameFormat = config["localFileSystem:fileNameFormat"].Trim('.');
        }

        public string FileName(DateTime fileDataDate, DateTime createDateTime)
        {
            string name = String.Format(FileNameFormat, fileDataDate.ToString(FileDataDateFormat), createDateTime.ToString(FileCreateDateFormat));
            string fullName = String.Format(@"{0}.{1}", name, FileExtension);
            return fullName;
        }
    }
}
