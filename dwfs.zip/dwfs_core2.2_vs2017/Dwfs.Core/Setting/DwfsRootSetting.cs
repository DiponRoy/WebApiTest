﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Dwfs.Core.Setting
{
    public interface IDwfsRootSetting
    {
        IConfigurationRoot Config { get; }
        RemoteSystemSetting RemoteSystem { get; }
    }

    public abstract class DwfsRootSetting: IDwfsRootSetting
    {
        public IConfigurationRoot Config { get; protected set; }
        public ConnectionStringSetting DbSetting { get; protected set; }
        public RemoteSystemSetting RemoteSystem { get; protected set; }
        public LocalFileSystemSetting LocalFileSystem { get; protected set; }
        public SourceDbQuerySetting SourceDbQuery { get; protected set; }

        protected DwfsRootSetting()
        {
            Config = GetConfig();
            DbSetting = new ConnectionStringSetting(Config);
            RemoteSystem = new RemoteSystemSetting(Config);
            LocalFileSystem = new LocalFileSystemSetting(Config);
            SourceDbQuery = new SourceDbQuerySetting(Config);
        }

        protected abstract IConfigurationRoot GetConfig();
    }
}
