﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Dwfs.Core.Setting
{
    public class AppConfig
    {
        public IConfigurationRoot Config { get; private set; }

        private static AppConfig _instance = null;
        public static AppConfig Instance
        {
            get
            {
                if (_instance == null)
                {
                    _instance = new AppConfig();
                }
                return _instance;
            }
        }

        private AppConfig()
        {
            Config = Build();
        }

        private static IConfigurationRoot Build()
        {
            var builder = new ConfigurationBuilder()
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "appsettings.json"), optional: true, reloadOnChange: true)
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "ConfigFile", "connectionString.json"), optional: true)
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "ConfigFile", "localFileSystem.json"), optional: true)
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "ConfigFile", "remoteSystem.json"), optional: true)
                .AddJsonFile(Path.Combine(AppContext.BaseDirectory, "ConfigFile", "serilog.json"), optional: true)
                .AddXmlFile(Path.Combine(AppContext.BaseDirectory, "ConfigFile", "SourceDbQuery.xml"), optional: true);
            IConfigurationRoot configuration = builder.Build();
            return configuration;
        }
    }
}
