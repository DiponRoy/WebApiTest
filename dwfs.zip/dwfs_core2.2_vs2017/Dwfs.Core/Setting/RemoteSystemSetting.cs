﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace Dwfs.Core.Setting
{
    public class RemoteSystemSetting
    {
        public string Type { get; private set; }

        public string Host { get; private set; }
        public int Port { get; private set; }
        public string UserName { get; private set; }
        public string Password { get; private set; }
        public string AbsoluteRootDirectory { get; private set; }

        public RemoteSystemSetting(IConfigurationRoot config)
        {
            Type = config["remoteSystem:type"];
            Host = config["remoteSystem:host"];
            Port = Convert.ToInt32(config["remoteSystem:port"]);
            UserName = config["remoteSystem:userName"];
            Password = config["remoteSystem:password"];
            AbsoluteRootDirectory = config["remoteSystem:absoluteRootDirectory"];
        }
    }  
}
