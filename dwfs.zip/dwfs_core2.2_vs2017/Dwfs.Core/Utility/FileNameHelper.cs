﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Dwfs.Core.Utility
{
    public class FileNameHelper
    {

    }
}
