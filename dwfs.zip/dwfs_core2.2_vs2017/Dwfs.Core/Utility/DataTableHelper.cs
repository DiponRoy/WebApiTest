﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Dwfs.Core.Utility
{
    public class DataTableHelper
    {
        /*https://stackoverflow.com/a/28503521*/
        public static string DataTableToFileContent(DataTable datatable, string seperator = ",", bool inchuleColumnName = true, string defaultNullColumnValue = "Null", bool trimColumValue = false)
        {
            StringBuilder sb = new StringBuilder();

            if (inchuleColumnName)
            {
                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    sb.Append(datatable.Columns[i]);
                    if (i < datatable.Columns.Count - 1)
                    {
                        sb.Append(seperator);
                    }
                }
                sb.AppendLine();
            }

            long lineNo = 0;
            string value;
            foreach (DataRow dr in datatable.Rows)
            {
                lineNo++;
                if (lineNo > 1)
                {
                    sb.AppendLine();
                }
                for (int i = 0; i < datatable.Columns.Count; i++)
                {
                    var columnValue = dr[i];
                    value = columnValue == DBNull.Value ? defaultNullColumnValue : columnValue.ToString();
                    if (trimColumValue)
                    {
                        value = value.Trim();
                    }
                    sb.Append(value);
                    if (i < datatable.Columns.Count - 1)
                    {
                        sb.Append(seperator);
                    }
                }
            }
            return sb.ToString();
        }
    }
}
