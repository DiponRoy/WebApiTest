﻿using System.Threading;
using System.Threading.Tasks;
using Quartz;

namespace Sched.Core.Schedule
{
    public class ScheduleJobListener : IJobListener
    {
        public event TaskExecution Started;
        public event TaskExecution Vetoed;
        public event TaskExecutionComplete Executed;

        public ScheduleJobListener(string name)
        {
            Name = name;
        }

        public Task JobToBeExecuted(IJobExecutionContext context, CancellationToken cancellationToken = default(CancellationToken))
        {
            var task = new Task(() => Started?.Invoke());
            task.Start();
            task.Wait();
            return task;
        }

        public Task JobExecutionVetoed(IJobExecutionContext context, CancellationToken cancellationToken = default(CancellationToken))
        {
            var task = new Task(() => Vetoed?.Invoke());
            task.Start();
            task.Wait();
            return task;
        }

        public Task JobWasExecuted(IJobExecutionContext context, JobExecutionException jobException, CancellationToken cancellationToken = default(CancellationToken))
        {
            var task = new Task(() => Executed?.Invoke(jobException));
            task.Start();
            task.Wait();
            return task;
        }

        public string Name { get; }
    }
}