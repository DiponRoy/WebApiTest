﻿using System;

namespace Sched.Core.Schedule
{
    public delegate void TaskExecution();
    public delegate void TaskExecutionComplete(Exception exception);
}
