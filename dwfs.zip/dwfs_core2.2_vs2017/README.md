
# CFS-Date Wise File System (CFS-Dwfs)

**Does**
 - Creates date wise files to a local folder
 - Upload files to a SFTP server
 - Creates Db log
	 - File create
	 - File transfer
	 
**External System Integrations**
 - DB 
	 - Oracle
 - File Transfer
	 - SFTP
	 
## .Net Framework:

 .Net Core 2.0

## Code Editor:

 - Vs2017 
 - Notepad++ 

## Programming language:

 - C#
 - PL/SQL
 - Json, XML

## Tools:

 - EF (Db ORM) 
 - Quartz (Scheduler)
 -  SSH.NET (SFTP) 

## Solutions:
 1. Schedulers

## Schedulers
Desktop console application

**Cons.Sched.Dwfs.DataProcess:**                        
Only once a day at 3:00 AM

## Tests-Nunit
 - Not yet

## Configuration Files:

**appsettings.json**

Define the root level configuration related to scheduler 

>Schedule run time:  "value": "0/45 0-59 0-23 * * ?" 
>Avoid running tasks on next run: "shouldStopOnTextRun": false
>Enable file create: "shouldCreateFile": true
>Enable file upload: "shouldUploadFile": true
>Db row process batch size: "fileCreateBatchSize"/"fileUploadBatchSize"

    {
      "scheduler": {
        "shouldStopOnTextRun": false,
        "cronExpression": {
          "value": "0/45 0-59 0-23 * * ?",
          "description": "12 AM to 11 PM every 45 second"
        }
      },
    
      "processes": {
        "shouldCreateFile": true,
        "fileCreateBatchSize": 30,
    
        "shouldUploadFile": true,
        "fileUploadBatchSize": 30
      }
    }
    	

**ConfigFile/connectionString.json**

Define the conneection string for source Db and Log Db 

>Source Database type:  "dbType": "database provider type"
>Source Database Connection string: "dbConnection": "connection string"
>Log Database type : "dbType": "database provider type"   
>Log Database connection string: "dbConnection": "connection string"

    {
          "connectionStrings": {
                "sourceDb": {
                      "dbType": "oracle",
                      "dbConnection": "XXXXXXX"
                   },

               "logDb": {
                    "dbType": "oracle",
                    "dbConnection": "XXXXXXX"
                 }
         }
	  }

**ConfigFile/localFileSystem.json**

Define the local file system setting in application 

>Directory where the local file created: "fileCreateAbsoluteDirectory": "C:\\Dwfs\\Files"
>Avoid creating the empty files: "avoidCreatingEmptyFile": true
>Sepration in file:"columnSeperator": "," 
>Should header include in file:"shouldIncludeHeader": true
>Replace null values to another value:"nullColumnsDefaultValue": ""
>Remove extra spaces in value: "shouldTrimColumnsValue": false
>File extension:"fileExtension": "csv"
>File data date format:"fileDataDateFormat": "yyyyMMdd"
>File Created date format:"fileCreateDateFormat": "yyyyMMdd" 
>File name fomat defined: "fileNameFormat": "NNPS_DUMP_{0}"
	
		{
			"localFileSystem": {
     		"fileCreateAbsoluteDirectory": "C:\\Dwfs\\Files",
			"avoidCreatingEmptyFile": true,
			"columnSeperator": ",",
			"shouldIncludeHeader": true,
			"nullColumnsDefaultValue": "",
			"shouldTrimColumnsValue": false,
			"fileExtension": "csv",
			"fileDataDateFormat": "yyyyMMdd", /*{0}*/
			"fileCreateDateFormat": "yyyyMMdd", /*{1} optional*/
			"fileNameFormat": "NNPS_DUMP_{0}"
		}
	}

**ConfigFile/remoteSystem.json**

Define the remote SFTP / FTP connection details
> Type of remote system:"type": "sftp"
> Host:"host": "xx.xx.xx.xx"
> PORT:"port": "xx"
> User Name:"userName": "xxxxxxxxx"
> Password:"password": "xxxx@xxx"
> Define the path of absolute root directory:"absoluteRootDirectory": "/xxx/xx/xx/xx"
	
	{
		"remoteSystem": {
				"type": "sftp",
				"host": "xx.xx.xx.xx",
				"port": "xx",
				"userName": "xx0xx0",
				"password": "xxxx@xx",
				"absoluteRootDirectory": "xx/xx"
				}
	}

**ConfigFile/serilog.json**

Define Seri log configuration details 
>Assign the path where error log inserted 

	{
		"serilog": {
			"errorDir": {
			"schedulers": "C:\\Dwfs\\Errors\\schedulers"
			}
		}
	}

**ConfigFile/SourceDbQuery.xml**
Define the dynamic query for geeting data from respected source

Collection data from and to between dates 
> Collection form date value: `<ForDateBuffter>-1</ForDateBuffter>`
> Collection to date value :`<ToDateBuffter>-1</ToDateBuffter>`
> Assign the parameter name: `<DateParameterName>loadDateParam</DateParameterName>`
> Assign the query with paramter used: 
    `<ParameterizedQuery>
	  SELECT   *  FROM DUAL;
    </ParameterizedQuery>`
  

    <Configuration>
    	<SourceDbQuery>
    		<ForDateBuffter>-1</ForDateBuffter>
    		<ToDateBuffter>-1</ToDateBuffter>
    		<DateParameterName>loadDateParam</DateParameterName>
    		<ParameterizedQuery>SELECT * FROM Dual</ParameterizedQuery>
    	</SourceDbQuery>
    </Configuration>`

## Testing:

 - Console UI: 10.10.20.49

## Development Server:
10.10.20.49

